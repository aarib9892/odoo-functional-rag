# M1.2 benchmark review — draft 0.1

Prepared 2026-10-22. All 30 cases require human review. Source: Odoo 19.0 / en, reported commit `c9202e68ae702daec981b47d0b6055191084ffa2`.

This file is rendered from `benchmark.draft.json`. Review the question conditions, proposed answer points, source spans and unsupported claims. A checked box should mean a human has actually verified that case against the supplied source; no boxes have been checked by the assistant.

Required evidence groups are separate facts. Within a group, `all` requires its listed spans; `any` would mean alternatives. Optional groups are not recall requirements. Unanswerable cases test boundaries; their contextual spans are not evidence for the unsupported answer.

The 23 development and 7 holdout cases are separated by question family. The holdout is author-visible and provisional, not a blind test. Freeze the approved benchmark before retrieval tuning.

## M12-DRAFT-001 — direct / development

**Question:** I changed Sales settings to Invoice what is delivered. Do existing products change automatically, and where do I update them?

**Expected behavior:** answer

**Proposed answer points:**

- The default applies to newly created products; existing products need a manual change.
- Open Sales → Products → Products, select the product and change Invoicing Policy under General Information.

**Evidence:**

- Required: Default versus existing products (all).
  - [invoicing_policy.rst, lines 25–31](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/invoicing/invoicing_policy.rst#L25-L31) — Opening configuration.
- Required: Existing-product update (all).
  - [invoicing_policy.rst, lines 45–48](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/invoicing/invoicing_policy.rst#L45-L48) — Changing the invoicing policy for existing products.

**Must not claim:**

- All existing products or past orders are retroactively changed.

Family: `invoice_eligibility`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-002 — workflow / development

**Question:** A confirmed sales order is for 10 units using Delivered quantities. Six have been delivered and validated, none invoiced, and four will ship later. What quantities can I invoice now and later?

**Expected behavior:** answer

**Proposed answer points:**

- Create a regular invoice for the six validated delivered units now.
- Invoice the other four after their later delivery is validated, assuming no intervening returns or invoicing.

**Evidence:**

- Required: Delivery prerequisite (all).
  - [invoicing_policy.rst, lines 109–118](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/invoicing/invoicing_policy.rst#L109-L118) — Invoice delivered quantity workflow.
- Required: Staged invoicing (all).
  - [invoicing_policy.rst, lines 128–133](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/invoicing/invoicing_policy.rst#L128-L133) — Partial-delivery example.

**Must not claim:**

- All ten are invoiceable merely because the order is confirmed.
- Validation automatically creates or pays an invoice.

**Review note:** 10/6/4 applies the documented rule to a new example; the source example is 50/40/10.

Family: `invoice_eligibility`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-003 — direct / development

**Question:** Can I enable Automatic Invoice on online payment while using Invoice what is delivered?

**Expected behavior:** answer

**Proposed answer points:**

- The selected documentation explicitly says this combination is unavailable.
- Regular draft invoices require the delivery order to be processed and validated.

**Evidence:**

- Required: Explicit restriction (all).
  - [invoicing_policy.rst, lines 36–40](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/invoicing/invoicing_policy.rst#L36-L40) — Important: Automatic Invoice.

**Must not claim:**

- The restriction proves all online payment order confirmation is unavailable.
- A retrieval miss proves a feature is unsupported.

Family: `invoice_eligibility`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-004 — workflow / development

**Question:** My confirmed order is for 10 physical units using Delivered quantities, with nothing invoiced. I am following the documented shipment workflow, and the delivery operation type has Create Backorder set to Ask. Only six units are shipping now. How do I validate six, keep four for later, and invoice six?

**Expected behavior:** answer

**Proposed answer points:**

- Prepare and record the six units actually shipping now.
- Validate and choose Create Backorder in the Ask flow; the four remaining units go to a later delivery order.
- Return to the sales order and create a regular invoice for the six delivered units.
- Later delivered quantities can be invoiced after validation.

**Evidence:**

- Required: Backorder policy condition (all).
  - [operation_type.rst, lines 35–38](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/inventory_and_mrp/inventory/warehouses_storage/inventory_management/operation_type.rst#L35-L38) — Create Backorder setting.
- Required: Immediate shipment and later order (all).
  - [multipack.rst, lines 78–90](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/inventory_and_mrp/inventory/shipping_receiving/setup_configuration/multipack.rst#L78-L90) — Create a backorder for items to be shipped later.
- Required: Invoice after validated delivery (all).
  - [invoicing_policy.rst, lines 109–118](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/invoicing/invoicing_policy.rst#L109-L118) — Invoice delivered quantity workflow.
- Required: Staged invoice quantities (all).
  - [invoicing_policy.rst, lines 128–133](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/invoicing/invoicing_policy.rst#L128-L133) — Partial-delivery example.

**Must not claim:**

- Record four as the immediate shipment quantity.
- Every backorder configuration shows the popup.
- A backorder automatically creates the invoice.
- Packages must be enabled for every possible backorder workflow.

**Review note:** Refines earlier draft 004 with the newly reviewed Ask condition. The arithmetic is an application of the documented rules.

Family: `invoice_eligibility`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-005 — direct / holdout

**Question:** All items in one delivery order will ship together, but they need two physical packages. Does that alone require a backorder?

**Expected behavior:** answer

**Proposed answer points:**

- No. One delivery order can contain multiple packages.
- A backorder handles items being shipped later.

**Evidence:**

- Required: Multiple packages on one order (all).
  - [multipack.rst, lines 5–8](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/inventory_and_mrp/inventory/shipping_receiving/setup_configuration/multipack.rst#L5-L8) — Introduction.
- Required: Backorder purpose (all).
  - [multipack.rst, lines 78–79](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/inventory_and_mrp/inventory/shipping_receiving/setup_configuration/multipack.rst#L78-L79) — Create a backorder for items to be shipped later.

**Must not claim:**

- One package requires one delivery order.
- Two packages necessarily mean a partial delivery.

Family: `package_meaning`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-006 — direct / development

**Question:** A customer returns an item after invoicing. Is a warehouse Reverse Transfer alone enough to complete the invoice correction?

**Expected behavior:** answer

**Proposed answer points:**

- No. The documented after-invoicing flow uses a Reverse Transfer together with a Credit Note.
- The physical return and invoice correction are separate operations.

**Evidence:**

- Required: After-invoicing branch (all).
  - [returns.rst, lines 66–71](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/products_prices/returns.rst#L66-L71) — After invoicing.

**Must not claim:**

- A warehouse return alone refunds or cancels the posted invoice.

Family: `returns_refunds`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-007 — ambiguous / development

**Question:** The customer wants to return two delivered items. What should I do?

**Expected behavior:** clarify

**Proposed answer points:**

- Ask whether the invoice has been sent or validated, and whether a monetary refund is needed.
- Explain conditionally that the physical return is a Reverse Transfer, while an invoiced return also needs credit-note handling.

**Evidence:**

- Required: Before-invoicing branch (all).
  - [returns.rst, lines 13–17](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/products_prices/returns.rst#L13-L17) — Before invoicing.
- Required: After-invoicing branch (all).
  - [returns.rst, lines 66–71](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/products_prices/returns.rst#L66-L71) — After invoicing.

**Must not claim:**

- Assume the invoice status.
- Give one unconditional return/refund procedure.

Family: `returns_refunds`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-008 — unanswerable / development

**Question:** I confirmed a credit note. Will the refund arrive in the customer bank account tomorrow?

**Expected behavior:** insufficient_evidence

**Proposed answer points:**

- The documentation does not establish bank settlement timing or the status of this real payment.
- A credit note alone does not prove money was sent; the page calls for registering payment when money is refunded.
- Ask for the payment status/provider or bank information needed to investigate.

**Evidence:**

- Required: Monetary refund requires additional action (all).
  - [credit_notes.rst, lines 19–22](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/finance/accounting/customer_invoices/credit_notes.rst#L19-L22) — Opening note.

**Must not claim:**

- Guarantee tomorrow or any settlement date.
- A confirmed credit note proves a completed bank refund.

**Review note:** Evidence supports the limited explanation; it is not a positive evidence target for a bank-arrival prediction.

Family: `returns_refunds`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-009 — direct / development

**Question:** What is the difference between Reverse and Reverse and Create Invoice when creating a customer credit note?

**Expected behavior:** answer

**Proposed answer points:**

- Reverse opens an editable draft credit note; product/quantity can be adjusted before confirmation, including for a partial refund.
- Reverse and Create Invoice validates and reconciles the credit note with the related invoice and opens a new draft invoice.

**Evidence:**

- Required: Reverse (all).
  - [credit_notes.rst, lines 36–38](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/finance/accounting/customer_invoices/credit_notes.rst#L36-L38) — Issue a customer credit note.
- Required: Reverse and Create invoice (all).
  - [credit_notes.rst, lines 39–41](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/finance/accounting/customer_invoices/credit_notes.rst#L39-L41) — Issue a customer credit note.

**Must not claim:**

- Both actions leave the same editable draft credit note.
- The second action merely sends cash to the customer.

**Review note:** Use the dedicated credit-note explanation; returns.rst 112–115 compresses the actions in a way that can mislead. Live UI behavior is untested.

Family: `returns_refunds`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-010 — workflow / development

**Question:** Five units were delivered and invoiced. The customer returns two, and I need to record their physical return and a credit for those two. What is the documented process?

**Expected behavior:** answer

**Proposed answer points:**

- Open the validated delivery from the sales order, choose Return and set the returned quantity to two.
- Create the return operation and validate it when the goods are received; Delivered updates accordingly.
- Open the invoice, choose Credit Note and enter the reason/journal/date as appropriate.
- Use Reverse, adjust the draft to the two returned units and confirm it.
- If money is to be refunded, payment registration is a separate step.

**Evidence:**

- Required: Physical return (all).
  - [returns.rst, lines 84–93](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/products_prices/returns.rst#L84-L93) — After invoicing.
- Required: Partial credit (all).
  - [credit_notes.rst, lines 29–38](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/finance/accounting/customer_invoices/credit_notes.rst#L29-L38) — Issue a customer credit note.
- Required: If refunding money (all).
  - [credit_notes.rst, lines 19–22](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/finance/accounting/customer_invoices/credit_notes.rst#L19-L22) — Opening note.

**Must not claim:**

- Credit all five by default without adjustment.
- Physical validation alone changes the invoice or sends money.

**Review note:** The two-unit quantity is a scenario applying the documented partial-credit option, not a copied worked example.

Family: `returns_refunds`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-011 — direct / development

**Question:** Is a down-payment invoice the same as paying one invoice through several installments?

**Expected behavior:** answer

**Proposed answer points:**

- No. Down-payment invoices differ from payment terms/installment plans.
- Multiple installments for a single invoice use payment terms with an installment plan.

**Evidence:**

- Required: Explicit distinction (all).
  - [down_payment.rst, lines 19–23](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/invoicing/down_payment.rst#L19-L23) — Opening note.

**Must not claim:**

- Provide unreviewed payment-term setup instructions.
- Treat both choices as the same invoicing structure.

Family: `down_payment_lifecycle`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-012 — direct / development

**Question:** Why does Create Invoice remain visible after a 100% down payment?

**Expected behavior:** answer

**Proposed answer points:**

- The source distinguishes a 100% down payment from completion through a regular invoice.
- Another invoice is required to complete the sales order, so Create Invoice remains available.

**Evidence:**

- Required: 100% down-payment distinction (all).
  - [down_payment.rst, lines 76–80](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/invoicing/down_payment.rst#L76-L80) — Types of down payments.

**Must not claim:**

- Charge another 100% as a new unpaid balance.
- A full down payment necessarily completes the regular-invoice lifecycle.

Family: `down_payment_lifecycle`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-013 — workflow / development

**Question:** For a product using Ordered quantities, how do I invoice a 50% down payment and later invoice the remaining balance?

**Expected behavior:** answer

**Proposed answer points:**

- Confirm the quotation, choose Create Invoice → Down payment (percentage), and enter 50.
- Create Draft, review and Confirm; record payment through Pay/Create Payment when appropriate.
- Later choose Create Invoice → Regular invoice, review the remaining Amount Due, create and confirm the draft, then record payment.
- In Payment versus Paid depends on the database/payment confirmation configuration described by the source.

**Evidence:**

- Required: Policy and initial percentage (all).
  - [down_payment.rst, lines 95–108](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/invoicing/down_payment.rst#L95-L108) — Example 1: 50% down payment.
- Required: Posting and payment (all).
  - [down_payment.rst, lines 115–139](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/invoicing/down_payment.rst#L115-L139) — Example 1: 50% down payment.
- Required: Remaining regular invoice (all).
  - [down_payment.rst, lines 144–166](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/invoicing/down_payment.rst#L144-L166) — Example 1: 50% down payment.

**Must not claim:**

- The second invoice should collect the full order total again.
- In Payment always proves settlement.
- Apply this example unconditionally to Delivered quantities.

Family: `down_payment_lifecycle`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-014 — ambiguous / development

**Question:** My customer wants to pay part now and the rest later. How should I configure that?

**Expected behavior:** clarify

**Proposed answer points:**

- Ask whether this means installments on one invoice or a separate advance/down-payment invoice followed by later invoicing.
- Explain the documented distinction before prescribing a workflow.

**Evidence:**

- Required: Single invoice with installments (all).
  - [down_payment.rst, lines 19–23](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/invoicing/down_payment.rst#L19-L23) — Opening note.
- Required: Down-payment invoice options (all).
  - [down_payment.rst, lines 37–42](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/invoicing/down_payment.rst#L37-L42) — Create invoices.
- Required: Later regular invoice (all).
  - [down_payment.rst, lines 137–152](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/invoicing/down_payment.rst#L137-L152) — Example 1: 50% down payment.

**Must not claim:**

- Assume down payments are required.
- Assume installment terms are required.
- Invent detailed payment-term configuration from an unreviewed page.

Family: `down_payment_lifecycle`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-015 — direct / development

**Question:** Do I need Multi-Step Routes for one-step shipping, and why might the Shipments settings be missing from my warehouse form?

**Expected behavior:** answer

**Proposed answer points:**

- The default one-step process does not require Multi-Step Routes.
- The documentation says enabling it exposes Shipments settings and also enables Storage Locations.

**Evidence:**

- Required: Default versus settings visibility (all).
  - [receipts_delivery_one_step.rst, lines 33–43](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/inventory_and_mrp/inventory/shipping_receiving/daily_operations/receipts_delivery_one_step.rst#L33-L43) — Configuration.

**Must not claim:**

- It is always required to perform one-step delivery.
- Enabling it automatically changes all shipments to multiple steps.

Family: `warehouse_routes`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-016 — direct / development

**Question:** Can one warehouse receive goods in one step but deliver them in three steps?

**Expected behavior:** answer

**Proposed answer points:**

- Yes. Incoming and outgoing shipment step counts can differ; the source gives this exact example.

**Evidence:**

- Required: Independent step counts (all).
  - [receipts_delivery_one_step.rst, lines 13–17](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/inventory_and_mrp/inventory/shipping_receiving/daily_operations/receipts_delivery_one_step.rst#L13-L17) — Opening tip.

**Must not claim:**

- Both directions must use the same count.
- The user warehouse is already configured that way.

Family: `warehouse_routes`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-017 — workflow / development

**Question:** My warehouse uses one-step outgoing shipments. A confirmed sales order for physical goods uses Delivered quantities; all units are ready to ship and none have been invoiced. What steps come before the regular invoice?

**Expected behavior:** answer

**Proposed answer points:**

- Open the sales order Delivery smart button.
- Record the quantity actually being shipped; for this full shipment it matches Demand.
- Validate the delivery; it becomes Done and Delivered updates on the sales order.
- Return to the sales order and create the regular invoice.

**Evidence:**

- Required: Open delivery (all).
  - [receipts_delivery_one_step.rst, lines 118–122](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/inventory_and_mrp/inventory/shipping_receiving/daily_operations/receipts_delivery_one_step.rst#L118-L122) — Create sales order.
- Required: Process delivery (all).
  - [receipts_delivery_one_step.rst, lines 131–144](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/inventory_and_mrp/inventory/shipping_receiving/daily_operations/receipts_delivery_one_step.rst#L131-L144) — Process delivery.
- Required: Regular invoice prerequisite (all).
  - [invoicing_policy.rst, lines 109–122](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/invoicing/invoicing_policy.rst#L109-L122) — Invoice delivered quantity workflow.

**Must not claim:**

- Sales-order confirmation alone completes the delivery.
- Always copy full Demand for a partial shipment.
- Delivery validation automatically creates or pays the invoice.

Family: `invoice_eligibility`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-018 — direct / holdout

**Question:** For Goods, how do tracked and untracked products differ in on-hand/forecast quantities, and can both still appear on transfers?

**Expected behavior:** answer

**Proposed answer points:**

- Tracked goods have on-hand and forecast quantity tracking; untracked goods do not have those tracked quantities.
- Both tracked and untracked goods can be used on transfers.

**Evidence:**

- Required: On-hand and forecast table rows (all).
  - [type.rst, lines 137–149](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/inventory_and_mrp/inventory/product_management/configure/type.rst#L137-L149) — Inventory operations by product type.
- Required: Transfer table row (all).
  - [type.rst, lines 170–172](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/inventory_and_mrp/inventory/product_management/configure/type.rst#L170-L172) — Inventory operations by product type.

**Must not claim:**

- Untracked goods cannot move through transfers.
- Untracked means the product has zero physical stock.

Family: `product_tracking`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-019 — direct / holdout

**Question:** What is the difference between an Inventory package and product packaging such as a six-pack?

**Expected behavior:** answer

**Proposed answer points:**

- A package is a physical container that can hold multiple products.
- Packaging describes a product-specific quantity, such as a six-pack, and is defined for that product.

**Evidence:**

- Required: Package (all).
  - [package.rst, lines 7–16](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/inventory_and_mrp/inventory/product_management/configure/package.rst#L7-L16) — Introduction.
- Required: Packaging (all).
  - [packaging.rst, lines 7–12](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/inventory_and_mrp/inventory/product_management/configure/packaging.rst#L7-L12) — Introduction.

**Must not claim:**

- The two terms are interchangeable.
- A product packaging definition can freely mix different products.

Family: `package_meaning`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-020 — direct / holdout

**Question:** Pro-forma invoices are enabled, but I have already sent a down-payment invoice for this sales order. Why can I not send its pro-forma invoice?

**Expected behavior:** answer

**Proposed answer points:**

- The page explicitly lists a previously sent down-payment invoice as a restriction on sending a pro-forma for that order.

**Evidence:**

- Required: Down-payment restriction (all).
  - [proforma.rst, lines 36–43](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/invoicing/proforma.rst#L36-L43) — Send pro-forma invoice.

**Must not claim:**

- Assume the feature is disabled despite the question.
- All new subscription quotations are excluded.
- A pro-forma itself is a payment request.

Family: `proforma_availability`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-021 — workflow / development

**Question:** A confirmed order uses two-step outgoing delivery and Delivered quantities. All units are available and nothing has been invoiced. What warehouse operations precede the regular invoice?

**Expected behavior:** answer

**Proposed answer points:**

- Validate the picking operation from stock to output with the actual full quantity.
- Then validate the delivery from output to the customer with the actual shipped quantity.
- Create the regular invoice after the customer delivery is validated.

**Evidence:**

- Required: Two operations (all).
  - [receipts_delivery_two_steps.rst, lines 151–153](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/inventory_and_mrp/inventory/shipping_receiving/daily_operations/receipts_delivery_two_steps.rst#L151-L153) — Process delivery order in two steps (pick + ship).
- Required: Pick (all).
  - [receipts_delivery_two_steps.rst, lines 184–204](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/inventory_and_mrp/inventory/shipping_receiving/daily_operations/receipts_delivery_two_steps.rst#L184-L204) — Process picking.
- Required: Customer delivery (all).
  - [receipts_delivery_two_steps.rst, lines 209–226](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/inventory_and_mrp/inventory/shipping_receiving/daily_operations/receipts_delivery_two_steps.rst#L209-L226) — Process delivery.
- Required: Invoice prerequisite (all).
  - [invoicing_policy.rst, lines 109–122](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/invoicing/invoicing_policy.rst#L109-L122) — Invoice delivered quantity workflow.

**Must not claim:**

- Validating only the internal pick completes customer delivery.
- Sales-order confirmation alone makes all quantities invoiceable.

Family: `invoice_eligibility`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-022 — workflow / development

**Question:** The delivery operation uses Manual reservation. My confirmed order is waiting, with enough unreserved stock available. How do I reserve the goods and complete delivery?

**Expected behavior:** answer

**Proposed answer points:**

- Manual reservation does not reserve merely on order confirmation.
- Open the delivery and use Check Availability to reserve available stock.
- Check the quantity actually shipping, then Validate when ready.

**Evidence:**

- Required: Manual behavior (all).
  - [manually.rst, lines 9–13](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/inventory_and_mrp/inventory/shipping_receiving/reservation_methods/manually.rst#L9-L13) — Introduction.
- Required: Reserve and deliver (all).
  - [manually.rst, lines 87–108](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/inventory_and_mrp/inventory/shipping_receiving/reservation_methods/manually.rst#L87-L108) — Workflow.

**Must not claim:**

- Waiting always means the warehouse has no stock.
- Manual reservation automatically reserves at confirmation.

Family: `reservation_diagnosis`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-023 — workflow / holdout

**Question:** Quotation templates are enabled. I want a template that requires both an online signature and online payment before order confirmation. What settings and customer actions are documented?

**Expected behavior:** answer

**Proposed answer points:**

- Enable/select both Online Signature and Online Payment for the template; the relevant global features must be available.
- Both conditions must be satisfied if both are selected.
- The customer signs through the portal and completes payment using a configured and published provider.
- Treat order confirmation separately from automatic invoice creation.

**Evidence:**

- Required: Both conditions and feature availability (all).
  - [quote_template.rst, lines 89–102](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/sales_quotations/quote_template.rst#L89-L102) — Create quotation templates.
- Required: Signature actions (all).
  - [get_signature_to_validate.rst, lines 53–66](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/sales_quotations/get_signature_to_validate.rst#L53-L66) — Order confirmations with online signatures.
- Required: Payment provider and payment (all).
  - [get_paid_to_validate.rst, lines 76–82](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/sales_quotations/get_paid_to_validate.rst#L76-L82) — Register a payment.

**Must not claim:**

- Either signature or payment alone suffices when both are required.
- Any payment provider appears without being configured and published.
- This guarantees an automatically posted invoice.

Family: `online_order_confirmation`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-024 — ambiguous / development

**Question:** I confirmed a sales order, but the stock is not reserved. What is wrong?

**Expected behavior:** clarify

**Proposed answer points:**

- Ask which reservation method is configured on the operation type, whether enough stock is available, and the scheduled/reservation dates if date-based.
- Manual, at-confirmation and before-scheduled-date methods have different expected timing.
- Do not diagnose a defect from confirmation alone.

**Evidence:**

- Required: Reservation choices (all).
  - [reservation_methods.rst, lines 18–33](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/inventory_and_mrp/inventory/shipping_receiving/reservation_methods.rst#L18-L33) — Reservation methods.
- Required: Stock condition (all).
  - [at_confirmation.rst, lines 9–10](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/inventory_and_mrp/inventory/shipping_receiving/reservation_methods/at_confirmation.rst#L9-L10) — Introduction.
- Required: Date-based timing (all).
  - [before_scheduled_date.rst, lines 94–103](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/inventory_and_mrp/inventory/shipping_receiving/reservation_methods/before_scheduled_date.rst#L94-L103) — Workflow.

**Must not claim:**

- A custom module is definitely required.
- Stock is always reserved immediately on confirmation.
- Missing reservation proves there is no stock.

Family: `reservation_diagnosis`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-025 — ambiguous / holdout

**Question:** How do I configure boxes of six?

**Expected behavior:** clarify

**Proposed answer points:**

- Ask whether six refers to a product-specific selling/handling quantity or physical shipping containers holding items.
- Then choose packaging or package guidance based on that meaning.

**Evidence:**

- Required: Physical container (all).
  - [package.rst, lines 7–16](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/inventory_and_mrp/inventory/product_management/configure/package.rst#L7-L16) — Introduction.
- Required: Product-specific quantity (all).
  - [packaging.rst, lines 7–12](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/inventory_and_mrp/inventory/product_management/configure/packaging.rst#L7-L12) — Introduction.

**Must not claim:**

- Assume the user means physical package types.
- Assume the user means a product six-pack.

Family: `package_meaning`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-026 — ambiguous / development

**Question:** I cannot create an invoice for this order. What should I change?

**Expected behavior:** clarify

**Proposed answer points:**

- Ask whether the order is confirmed, whether the user wants a regular invoice or a down payment, the product invoicing policy, and the delivery/validation state.
- Explain policy-dependent prerequisites conditionally; ask for the exact error when needed.

**Evidence:**

- Required: Ordered policy (all).
  - [invoicing_policy.rst, lines 58–61](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/invoicing/invoicing_policy.rst#L58-L61) — Invoicing what is ordered.
- Required: Delivered policy and warning (all).
  - [invoicing_policy.rst, lines 109–122](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/invoicing/invoicing_policy.rst#L109-L122) — Invoice delivered quantity workflow.
- Required: Invoice choices (all).
  - [down_payment.rst, lines 28–42](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/sales/sales/invoicing/down_payment.rst#L28-L42) — Create invoices.

**Must not claim:**

- Immediately switch the policy without diagnosing the workflow.
- Assume a software defect or a need for customization.
- All invoice types have identical delivery prerequisites.

Family: `invoice_eligibility`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-027 — unanswerable / development

**Question:** Can our warehouse fulfill 50 units of SKU CAB-001 today? Tell me the actual quantity available.

**Expected behavior:** insufficient_evidence

**Proposed answer points:**

- State that the documentation snapshot has no access to the real warehouse/product quantities or reservations.
- Request current warehouse/product availability and relevant dates, or explain where a tracked-product forecast can be inspected.

**Evidence:**

- Optional: Optional navigation help (all).
  - [forecast.rst, lines 17–30](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/inventory_and_mrp/inventory/warehouses_storage/reporting/forecast.rst#L17-L30) — Introduction and Navigating the report.

**Must not claim:**

- Invent current stock, reservations or a fulfillment promise.

**Review note:** The invented SKU identifies a hypothetical live-data request; no actual user database was queried.

Family: `live_database_boundary`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-028 — unanswerable / holdout

**Question:** Exactly what changed in the partial-delivery invoicing workflow between Odoo 18 and Odoo 19?

**Expected behavior:** insufficient_evidence

**Proposed answer points:**

- The reviewed corpus is a single Odoo 19 snapshot; it cannot establish a version-to-version change list.
- Request or review an appropriate Odoo 18 source snapshot and compare before answering the change question.

**Evidence:**

- No positive answer target: this is a corpus-boundary case.

**Must not claim:**

- Invent changes from Odoo 19 behavior alone.
- Treat a single-version page as evidence of a change.

**Review note:** Boundary case is justified by corpus metadata. It has no positive answer passage to retrieve.

Family: `version_comparison_boundary`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-029 — unanswerable / development

**Question:** Will our private custom delivery module work unchanged after upgrading to Odoo 19? Please guarantee compatibility.

**Expected behavior:** insufficient_evidence

**Proposed answer points:**

- The documentation-only corpus cannot establish compatibility of unseen custom code or a particular deployment.
- Request the module, dependencies, relevant versions and test results for a separate review.

**Evidence:**

- No positive answer target: this is a corpus-boundary case.

**Must not claim:**

- Guarantee compatibility.
- Claim the module definitely requires rewriting because retrieval found nothing.

**Review note:** No custom module source or runtime test evidence is included in this corpus.

Family: `custom_code_boundary`.

- [ ] Human reviewed; reviewer/date/corrections:

## M12-DRAFT-030 — unanswerable / development

**Question:** From the two journal-entry screenshots in Credit notes and refunds, list the exact account names and debit/credit amounts shown.

**Expected behavior:** insufficient_evidence

**Proposed answer points:**

- The reviewed text references screenshots but the image bytes were not supplied.
- Explain that the exact accounts and amounts cannot be extracted from the alt text; request the images or a text transcription.

**Evidence:**

- Required: Image-only details (all).
  - [credit_notes.rst, lines 109–118](https://github.com/odoo/documentation/blob/c9202e68ae702daec981b47d0b6055191084ffa2/content/applications/finance/accounting/customer_invoices/credit_notes.rst#L109-L118) — Journal entries example.

**Must not claim:**

- Invent the ledger accounts or numeric amounts.
- Present the generic reversal description as the exact image contents.

**Review note:** Keep this case valid only while the evaluation input remains text-only and the screenshot contents are unavailable.

Family: `returns_refunds`.

- [ ] Human reviewed; reviewer/date/corrections:
