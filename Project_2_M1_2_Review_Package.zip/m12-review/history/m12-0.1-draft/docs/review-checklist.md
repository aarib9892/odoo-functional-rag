# Human review and activation checklist

The canonical roadmap's M1 gate requires reviewed source/evidence labels. Assistant-authored questions are draft candidates, not approved gold answers.

- [ ] Review the 30-page selection and the exact one-page Accounting exception.
- [ ] Review all 30 cases against their source spans; record reviewer/date and correct questions, evidence and expected points.
- [ ] Confirm the source issues in the review summary are bounded adequately. Keep unclear claims out of approved expectations unless corroborated.
- [ ] Confirm/freeze family assignments and record the author-visible holdout limitation.
- [ ] Version the approved benchmark and selection together. Retain the draft for history.
- [ ] After approval, apply the exact-page proposal to the project configuration and regenerate the manifest using the existing CLI against the clean pinned checkout.
- [ ] Confirm the new manifest has 30 files: 9 Sales, 20 Inventory, 1 Accounting; verify its new fingerprint and source bytes.

All boxes remain unchecked. The uploaded archive cannot run or modify the user's local checkout. M1.2 stays in progress until the review and local activation evidence are recorded. M2 starts with a parser comparison on representative structures after this source/evaluation contract is ready.
