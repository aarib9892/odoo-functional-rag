# Source attribution

Source: Odoo S.A. and documentation contributors, official Odoo documentation repository, configured version 19.0 / English, reported commit `c9202e68ae702daec981b47d0b6055191084ffa2`.

Repository: https://github.com/odoo/documentation/tree/c9202e68ae702daec981b47d0b6055191084ffa2

The supplied repository root LICENSE identifies Creative Commons Attribution-ShareAlike 4.0 International. The supplied COPYRIGHT attributes most files to Odoo S.A. (2004–2023), with third-party contributions and possible per-file notices. Both files are preserved verbatim here. No separate license notice was observed in the selected RST pages.

License: https://creativecommons.org/licenses/by-sa/4.0/ and the included full license text.

This review package reorganizes source facts into selection notes and draft questions/expected answer points. These documentation-derived adaptations are offered under CC BY-SA 4.0. The package does not relicense the application's software. Preserve attribution, source/license links and modification notices when redistributing adapted documentation. No endorsement by Odoo is implied.

Each selected page's original commit-pinned URL and raw-file SHA-256 are in `docs/page-selection.json`. The source RST and screenshot files are not redistributed in this package. The input archive provides the RST locally; screenshots were absent.

The repository's `content/legal/licenses.rst` discusses Odoo software licenses; it is not the documentation's license grant. A separate Apache 2.0 notice exists for theme icon assets; those assets are not included here.

Prepared 2026-10-22. This notice records the supplied checkout materials and the official CC license summary; it does not assert that one license applies to all repository assets or deployments.
