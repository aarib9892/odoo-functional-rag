# Project 2 — M1.2 review package

Prepared 22 October 2026. **Status: accepted by Aarib on 22 October 2026; local activation pending.**

M1.1 made a reproducible list of candidate documents. M1.2 decides which documents we initially trust for answers, and which questions we will use to check the system later. The user has accepted the prepared selection and benchmark as presented. They are frozen as version m12-1.0.

## What was verified

- All **143 candidate RST files** match the manifest's byte sizes and SHA-256 hashes; total **1,103,702 bytes**.
- The candidate fingerprint reproduces exactly: `d2b2ef3824b6a6c78ceaafbc95d0ab146862493d13b8709f0dd60230fcbe1e2b`.
- Configuration and manifest agree on source and scope (scope arrays have harmless ordering differences).
- The source commit is reported as `c9202e68ae702daec981b47d0b6055191084ffa2`. The archive contains no Git history, so this checks byte consistency with the supplied manifest, not independent proof of commit membership or checkout cleanliness.
- The credit-note dependency's hash was computed separately; it was not part of the original 143-file manifest.

## Accepted starting scope

| Application | Pages | Purpose |
|---|---:|---|
| Sales | 9 | Quotations, invoicing policy, down payments, pro-forma restrictions and returns |
| Inventory | 20 | Product/warehouse basics, deliveries, backorders, reservations, packages and stock reports |
| Accounting | 1 | Exact credit-note page needed to finish the customer return workflow |
| Total | **30** | **213,145 source bytes** |

The accepted selection takes 29 pages from the existing candidate set and adds the credit-note dependency. The other 114 candidates are deferred with reasons. The selected 30 pages received full assistant text review; the deferred pages received path/title/structure screening. Whole-file inclusion brings some incidental vendor, Purchase and POS passages; it does not promise broad coverage of those applications.

`config/corpus.json` contains the accepted exact-page scope. The user accepted the single Accounting exception; broad Accounting and Purchase coverage remains deferred. Local activation and manifest regeneration are the next step. The original config proposal is preserved with the draft history.

## Accepted benchmark — m12-1.0

| Type | Count | What it checks |
|---|---:|---|
| Direct | 12 | A precise fact or configuration rule |
| Workflow / multiple sections | 8 | Prerequisites and steps combined correctly |
| Ambiguous | 5 | Useful clarification before prescribing changes |
| Unanswerable / outside available evidence | 5 | Acknowledging missing evidence without inventing an answer |

Every case has expected behavior, accepted answer points, forbidden claims, and source targets where applicable. Targets identify paths, sections, inclusive line spans and hashes. Required evidence groups separate distinct facts. Cases 001–017 retain their earlier IDs; 004 now specifies the **Ask** backorder setting, and 001 explicitly asks where existing products are updated.

The frozen benchmark uses **23 development / 7 holdout** cases, with each question family entirely in one split. The holdout has been seen by its author and is included for review: it is not blind or statistically representative. Some source documents support both splits. This version is frozen before retrieval tuning; no retrieval quality claim is made now.

## Findings that affect ingestion and answers

1. **Backorder behavior depends on configuration.** Operation types document Ask, Always and Never. The popup procedure is now scoped to Ask; it must not become a universal answer.
2. **Physical returns and credits are separate.** The Sales returns page links to Accounting. The dedicated credit-note page distinguishes an editable Reverse draft from Reverse and Create Invoice. The earlier compressed Sales wording cannot safely replace that distinction.
3. **Some source wording is imprecise.** One-step delivery introductions mention sales-order validation, while their explicit steps validate the delivery operation. The benchmark uses the explicit steps and keeps the conflict visible. The confusing down-payment/delivered-quantity edge case is excluded from approved expectations pending clarification.
4. **Screenshots are missing from this archive.** Paths and alt text remain available, but exact journal-entry account names/amounts cannot be read from them. One boundary case tests this limitation.
5. **RST structure carries meaning.** Beyond headings, roles and warnings, selected pages contain tables, tabs, substitutions, cards/toctrees and math blocks. M2 must preserve these or report unsupported structures; raw text flattening would lose distinctions.

Useful M2 fixtures: `type.rst` for table columns, `reservation_methods.rst` for tabs, `receipts_delivery_one_step.rst` for substitutions and operation steps, `new_delivery_method.rst` for formula blocks, and `invoicing_policy.rst` for warnings, labels and cross-document workflow references. This package's lexical structure inventory is an audit aid, not an RST parser. Runtime/Sphinx dependency versions remain to be inspected in M2; no repository extension code was run.

## License and attribution

The supplied root documentation LICENSE is CC BY-SA 4.0; COPYRIGHT identifies Odoo S.A. and contributors. The package includes both notices verbatim and a source-attribution note with pinned page links. The separate legal/licenses page discusses Odoo software licensing and must not be mistaken for the documentation license. See https://creativecommons.org/licenses/by-sa/4.0/ for the official summary. Documentation-derived adaptations in this package retain CC BY-SA 4.0; this does not choose a license for the application code.

## Accepted files

- `docs/page-selection.md`: the 30 pages, reasons and cautions.
- `evaluation/benchmark-review.md`: all 30 questions and source evidence in reading order.
- `evaluation/benchmark.json`: the same cases in structured form for later evaluation work.
- `config/corpus.json`: the accepted exact-page allowlist.
- `docs/candidate-decisions.json`, `structure-survey.json`, `dependencies.json`, `verification.json`: audit details and limits.
- `docs/review-checklist.md`: review and activation steps.

**Acceptance:** Aarib stated, “I reviewed the docs , looks fine to me , lets proceed” on 22 October 2026. This records acceptance of the supplied documents as a whole; no individual corrections were requested. See `docs/acceptance.json` for frozen hashes.

**Next step:** follow `ACTIVATE.md` to apply the accepted configuration and benchmark in the local project, regenerate the manifest and record its new fingerprint. M1.2 awaits that execution evidence. M2 then begins with a controlled parser comparison.

No live Odoo instance, parser, retriever or model answer evaluation was run in this review. No active local project files were changed by this package.
