# Apply the accepted M1.2 corpus

Download `Project_2_M1_2_Review_Package.zip` into `/home/aarib/odoo-functional-rag/`. From the project's `backend` directory, run these commands in order. The config backup retains the original broad candidate configuration. Stop if a command fails.

```bash
unzip -o ../Project_2_M1_2_Review_Package.zip -d ../data/m12
cp -n ../config/corpus.json ../config/corpus.candidates.json
cp ../data/m12/m12-review/config/corpus.json ../config/corpus.json
mkdir -p ../evaluation
cp ../data/m12/m12-review/evaluation/benchmark.json ../evaluation/odoo19-benchmark.v1.json

uv run python -m app.ingestion.cli \
  --repo ../sources/odoo-documentation \
  --config ../config/corpus.json \
  --output ../data/manifests/odoo19-corpus.json
```

Expected with the same clean pinned checkout:

```text
Commit: c9202e68ae702daec981b47d0b6055191084ffa2
Discovered: 944
Selected: 30
Excluded: 914
Source bytes: 213145
Fingerprint: <newly computed by your CLI>
Saved: /home/aarib/odoo-functional-rag/data/manifests/odoo19-corpus.json
```

The new selection is 9 Sales, 20 Inventory and one Accounting page. The credit-note page already belonged to the 944 discovered files; it was excluded by the earlier scope. The new fingerprint differs from the original candidate manifest because the scope and selected files changed. The earlier `odoo19-inventory.json` remains the candidate checkpoint.

Share the CLI output so the local activation checkpoint can be recorded. After it matches, begin M2 with a controlled parser comparison. Keep the accepted benchmark frozen as the reference while developing ingestion.
