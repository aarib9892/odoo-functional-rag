# Acceptance and local activation

Accepted by Aarib on 22 October 2026, as presented in the supplied review documents. See `acceptance.json` for the exact user statement, frozen file hashes and acceptance scope.

- [x] User accepted the 30-page selection, including the exact credit-note page exception.
- [x] User accepted the 30-case benchmark and its bounded source interpretations as presented.
- [x] Freeze version m12-1.0 and the 23 development / 7 author-visible holdout family assignments.
- [x] Preserve the original draft files under `history/m12-0.1-draft/`.
- [ ] Apply `config/corpus.json` in the local project and store `evaluation/benchmark.json`.
- [ ] Regenerate the manifest using the existing CLI against the clean pinned checkout.
- [ ] Verify 30 selected files, 213,145 source bytes and the newly generated fingerprint; record the local output.

Acceptance is based on the user's review statement for the package as a whole. No separate per-case comments or live runtime verification were supplied. M1.2 now awaits local activation evidence, with no further approval needed for these accepted files. The next implementation milestone is M2: compare controlled Docutils and Sphinx approaches on the audited fixtures.
