import unittest

from docutils import nodes
from docutils.utils import new_document

from app.ingestion.normalized_models import SourceIdentity
from app.ingestion.normalization import Normalizer


class NormalizationTests(unittest.TestCase):
    def normalizer(self, commit="commit-a"):
        return Normalizer(SourceIdentity("https://example.test/docs.git", "19.0", "en",
                                        commit, "content/example.rst", "source-hash", "sales"), "parser-v1")

    def test_unsupported_table_is_visible_with_fallback_text(self):
        tree = new_document("content/example.rst")
        table = nodes.table()
        table += nodes.paragraph("", "Answer-critical table contents")
        tree += table
        document = self.normalizer().normalize(tree)
        self.assertEqual(document.status, "partial")
        self.assertEqual(document.items[0].kind, "unsupported")
        self.assertIn("Answer-critical", document.items[0].text)
        self.assertEqual(document.diagnostics[0].code, "unsupported_block")

    def test_inherited_line_is_not_marked_as_a_node_line(self):
        tree = new_document("content/example.rst")
        paragraph = nodes.paragraph("", "Text without a child line")
        paragraph.line = 12
        tree += paragraph
        document = self.normalizer().normalize(tree)
        block = document.items[0]
        self.assertEqual(block.source.line_origin, "node")
        self.assertEqual(block.inlines[0].source.line, 12)
        self.assertEqual(block.inlines[0].source.line_origin, "ancestor")

    def test_identity_is_stable_and_revision_tracks_source_commit(self):
        tree = new_document("content/example.rst")
        tree += nodes.paragraph("", "Hello")
        normalizer = self.normalizer()
        first = normalizer.normalize(tree)
        self.assertEqual(first.to_json(), normalizer.normalize(tree).to_json())
        changed = self.normalizer("commit-b").normalize(tree)
        self.assertEqual(first.document_id, changed.document_id)
        self.assertNotEqual(first.revision_id, changed.revision_id)

    def test_foreign_source_is_rejected_instead_of_misattributed(self):
        tree = new_document("content/example.rst")
        paragraph = nodes.paragraph("", "Included from a second file")
        paragraph.source = "content/other.rst"
        paragraph.line = 5
        tree += paragraph
        with self.assertRaisesRegex(ValueError, "Unexpected node source"):
            self.normalizer().normalize(tree)


if __name__ == "__main__":
    unittest.main()
