"""First normalizer: core prose/list/admonition/image/reference structures.

Tables, tabs, cards and navigation get visible unsupported records until
their structured mappings are implemented in the next increment.
"""

import hashlib
import json
from pathlib import Path

from docutils import nodes
from sphinx import addnodes

from app.ingestion.normalized_models import (
    Block, Diagnostic, Inline, NormalizedDocument, Section,
    SourceIdentity, SourceLocation,
)
from app.ingestion.rst_directives import ExampleBlock


SCHEMA_VERSION = "m22-0.1"
NORMALIZER_VERSION = "core-0.1"


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode("utf-8")).hexdigest()


class Normalizer:
    def __init__(self, source: SourceIdentity, parser_id: str, source_root: Path | None = None):
        self.source = source
        self.parser_id = parser_id
        self.source_root = source_root.resolve() if source_root is not None else None
        self.sequence = 0
        self.issues = []

    def location(self, node) -> SourceLocation:
        current = node
        while current is not None:
            line = getattr(current, "line", None)
            if isinstance(line, int) and line > 0:
                return SourceLocation(self.source.source_path, line,
                                      "node" if current is node else "ancestor")
            current = current.parent
        return SourceLocation(self.source.source_path, None, "unknown")

    def next_id(self, prefix):
        self.sequence += 1
        return f"{prefix}{self.sequence:04d}"

    def issue(self, node, code):
        self.issues.append(Diagnostic("error", code,
                                     f"No structured mapping for {node.tagname}.",
                                     self.location(node)))

    def inline(self, node):
        attributes = {}
        if isinstance(node, nodes.Text):
            kind = "text"
        elif isinstance(node, addnodes.pending_xref):
            kind = "reference"
            attributes = {
                "reference_kind": node.get("reftype"),
                "domain": node.get("refdomain"),
                "target": node.get("reftarget"),
                "explicit_title": bool(node.get("refexplicit")),
                "resolution": "not_attempted",
            }
        elif isinstance(node, nodes.reference):
            kind = "reference"
            attributes = {
                "reference_kind": "external" if "refuri" in node else "local",
                "target": node.get("refuri", node.get("refid")),
                "resolution": "not_attempted",
            }
        elif type(node) is nodes.inline:
            classes = node.get("classes", [])
            kind = ("gui_label" if "guilabel" in classes else
                    "menu_path" if "menuselection" in classes else
                    "icon" if "odoo-icon" in classes else "span")
            attributes = {"classes": list(classes)}
            if node.get("rawtext"):
                attributes["raw_markup"] = node["rawtext"]
            if node.get("icon_name"):
                attributes["icon_name"] = node["icon_name"]
        elif isinstance(node, (nodes.strong, nodes.emphasis, nodes.literal, nodes.abbreviation)):
            kind = node.tagname
            if node.get("explanation"):
                attributes["explanation"] = node["explanation"]
        else:
            kind = "unsupported"
            attributes = {"node_type": node.tagname, "raw_source": node.rawsource}
            self.issue(node, "unsupported_inline")
        children = () if isinstance(node, nodes.Text) else tuple(self.inline(child) for child in node.children)
        return Inline(kind, node.astext(), self.location(node), attributes, children)

    def block(self, node, headings):
        block_id = self.next_id("b")
        kind, text, attributes, inlines, children = "", "", {}, (), ()
        if isinstance(node, nodes.paragraph):
            kind, text = "paragraph", node.astext()
            inlines = tuple(self.inline(child) for child in node.children)
        elif isinstance(node, nodes.image):
            kind = "image"
            attributes = {key: node[key] for key in
                          ("uri", "original_uri", "alt", "align", "width", "height") if key in node}
            attributes["asset_status"] = "not_checked"
        elif isinstance(node, nodes.target):
            kind = "anchor"
            attributes = {key: node[key] for key in ("ids", "names", "refid", "refuri") if key in node}
        elif isinstance(node, nodes.literal_block):
            kind, text = "literal", node.astext()
        elif isinstance(node, (nodes.bullet_list, nodes.enumerated_list, nodes.list_item, nodes.Admonition)):
            if isinstance(node, nodes.Admonition):
                kind = "admonition"
                attributes["admonition_type"] = "example" if isinstance(node, ExampleBlock) else node.tagname
            elif isinstance(node, nodes.enumerated_list):
                kind = "ordered_list"
                attributes = {key: node[key] for key in ("start", "enumtype", "prefix", "suffix") if key in node}
            else:
                kind = "bullet_list" if isinstance(node, nodes.bullet_list) else "list_item"
            children = tuple(self.block(child, headings) for child in node.children)
        else:
            kind, text = "unsupported", node.astext()
            attributes = {"node_type": node.tagname, "raw_source": node.rawsource}
            self.issue(node, "unsupported_block")
        return Block(block_id, kind, self.location(node), headings, text, attributes, inlines, children)

    def section(self, node, ancestors):
        section_id = self.next_id("s")
        title = next((child.astext() for child in node.children if isinstance(child, nodes.title)), "")
        headings = ancestors + (title,)
        items = tuple(self.section(child, headings) if isinstance(child, nodes.section)
                      else self.block(child, headings)
                      for child in node.children if not isinstance(child, nodes.title))
        return Section(section_id, title, self.location(node), headings,
                       tuple(node.get("ids", [])), tuple(node.get("names", [])), items)

    def normalize(self, tree, parser_diagnostics=""):
        # A Normalizer can be reused without leaking counters or diagnostics.
        self.sequence, self.issues = 0, []
        # This increment supports one source file. Refuse to misattribute nodes
        # from a second file; include/dependency provenance is a later mapping.
        for node in tree.findall():
            actual = getattr(node, "source", None)
            if actual:
                path = Path(actual)
                if path.is_absolute():
                    if self.source_root is None:
                        raise ValueError("source_root is required for absolute node source paths.")
                    path = path.relative_to(self.source_root)
                if path.as_posix() != self.source.source_path:
                    raise ValueError(f"Unexpected node source: {actual}")
        metadata = tuple({"name": node.get("name"), "content": node.get("content")}
                         for node in tree.children if isinstance(node, nodes.meta))
        items = tuple(self.section(child, ()) if isinstance(child, nodes.section)
                      else self.block(child, ())
                      for child in tree.children if not isinstance(child, nodes.meta))
        title = next((item.title for item in items if isinstance(item, Section)), "")
        document_id = digest([self.source.repository_url, self.source.odoo_version,
                              self.source.language, self.source.source_path])
        revision_id = digest([document_id, self.source.commit, self.source.sha256,
                              self.parser_id, SCHEMA_VERSION, NORMALIZER_VERSION])
        return NormalizedDocument(SCHEMA_VERSION, NORMALIZER_VERSION, self.parser_id,
                                  document_id, revision_id, self.source, title,
                                  "partial" if self.issues else "ok", metadata, items,
                                  tuple(self.issues), parser_diagnostics)
