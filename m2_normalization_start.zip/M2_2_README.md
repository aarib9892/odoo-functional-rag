# M2.2 — First normalized document

M2.1 is complete: the user reproduced the final 30-file Sphinx parsing/navigation checks. M2 remains in progress. This increment begins normalization with the already-reviewed invoicing-policy page.

Parsing gives us a Sphinx/Docutils tree. Normalization converts it into application-owned Python records and JSON. That gives the future chunker a stable interface without requiring it to understand Sphinx classes.

## Files

| File | Purpose |
|---|---|
| `app/ingestion/normalized_models.py` | Plain dataclasses describing source identity, locations, diagnostics, inline content, blocks, sections and a document |
| `app/ingestion/normalization.py` | Recursive mapping from the supported Sphinx/Docutils nodes into those records |
| `app/ingestion/normalization_demo.py` | Read the active manifest, check this fixture's bytes, parse it and save its normalized JSON |
| `tests/test_normalization.py` | Four focused checks for unsupported content, provenance and revision identity |

The existing `rst_directives.py` supplies the example adapter. No dependency changes are needed; use the existing `parser-spike` group under Python 3.12+.

## Record contract

| Record | Meaning |
|---|---|
| `SourceIdentity` | Repository, Odoo version, language, commit, relative path, source SHA-256 and application |
| `SourceLocation` | Relative source path, optional line and whether the line belongs to the node, an ancestor or is unknown |
| `Section` | Heading text, heading ancestry, anchors/labels and ordered section/block items |
| `Block` | A paragraph, list, list item, admonition, image, anchor, literal or visible unsupported record |
| `Inline` | Text with meaning such as strong emphasis, a GUI label, menu path, reference or abbreviation |
| `NormalizedDocument` | Source identity, title, ordered contents, metadata, IDs, parser identity and diagnostics |

Lists keep their list-item children; admonitions keep their own child blocks. For the warning at source line 120, the normalized warning contains its paragraph at line 121 and image at line 124. Its heading path remains `Invoicing policies` → `Invoice delivered quantity workflow`.

Inline reference records retain their original target and carry `resolution: not_attempted`. This first mapper uses the stored tree before reference resolution. The earlier Sphinx reference experiment demonstrated resolution; attaching resolved destinations to normalized references is a later increment.

Images retain URI/original URI, alt text and encountered display attributes, with asset status `not_checked`. Images are not copied into this temporary parsing project. Their parser warnings remain in `parser_diagnostics` inside the JSON.

Source lines do not claim end ranges. A child without its own line can inherit an ancestor's line, explicitly labeled `ancestor`. An unknown line remains null. This increment supports one source file and rejects nodes attributed to another file, rather than relabeling them as the main source.

`document_id` identifies repository/version/language/path. `revision_id` also depends on commit, source hash, parser configuration and schema/normalizer versions. Block and section IDs are deterministic traversal IDs local to a document revision; combine them with `revision_id` when referring to them externally. They are not promised to remain stable through source edits.

The schema is deliberately versioned `m22-0.1`. Dataclasses and type hints describe the contract; this is not a runtime JSON schema validator. `status: ok` means no unsupported mappings were encountered in this normalization run, not that every link/asset is validated or the document has passed a complete fidelity review.

## Run

Save `m2_normalization_start.zip` in `/home/aarib/odoo-functional-rag/`. From `backend`:

```bash
unzip -o ../m2_normalization_start.zip -d .
uv run --group parser-spike python -m unittest discover -s tests -p 'test_normalization.py' -v
uv run --group parser-spike python -m app.ingestion.normalization_demo
```

The demo writes:

```text
/home/aarib/odoo-functional-rag/data/normalized/examples/invoicing_policy.json
```

Assistant-local results, awaiting user reproduction:

```text
Ran 4 tests
OK

Document: Invoicing policies
Normalization status: ok
Sections: 6
Examples: 2; source lines: [75, 128]
Warning retains its paragraph, image and heading ancestry.
GUI labels: 17; menu paths: 2; reference targets: 9; images: 4
Reference resolution: not attempted in this first normalizer.
Unsupported-node diagnostics: 0
Source-line origins: {'node': 41}
Repeated normalization produced identical JSON.
```

Two independent assistant-local Sphinx processes also produced byte-identical JSON. The output contains no temporary-directory path. That evidence covers this fixture/configuration, not all 30 pages. Smart quotes are disabled in this new parsing configuration to avoid typography changes to the source text; the parser identity records that choice.

## Current boundary and next work

The mapper currently covers core prose, nested lists/admonitions, inline semantics, images, anchors and literal blocks on the invoicing-policy fixture. Unsupported blocks/inline nodes retain fallback text and a normalization diagnostic; the document becomes `partial`. The table fallback test checks this explicitly. Unsupported structures are not flattened and presented as successfully structured content.

Next: add typed table, tab, card, navigation and other encountered mappings; attach reference-resolution results; classify parser diagnostics; widen normalization to all 30 manifest files. Repeated full-corpus checks, selected rendered-page comparison, image/caption handling, include/dependency support and production atomic output remain pending. This demo checks the fixture's size/hash against its manifest record; it does not recheck the whole inventory fingerprint or Git cleanliness.

Read `normalized_models.py` first, then `normalization.py`. The demo supplies parsing and fixture validation around that mapping. These records are not chunks and no embeddings or model calls are made.
